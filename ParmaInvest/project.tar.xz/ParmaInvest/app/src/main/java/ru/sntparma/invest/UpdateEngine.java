package ru.sntparma.invest;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;

/** Обновляет котировки и правила, записывает только переход к новому сигналу BUY. */
public final class UpdateEngine {
    private UpdateEngine() { }
    public interface Progress {
        void onProgress(int done, int total, String ticker);
    }

    public static final class Result {
        public final int ok, errors, buys;
        public final String firstError;
        public Result(int ok, int errors, int buys, String firstError) {
            this.ok = ok; this.errors = errors; this.buys = buys; this.firstError = firstError;
        }
    }

    public static synchronized Result run(Context context, Progress progress) {
        Store store = new Store(context);
        List<String> tickers = new ArrayList<>(store.tickers());
        MoexClient client = new MoexClient();
        int ok = 0, errors = 0, buys = 0;
        String firstError = "";
        for (int i = 0; i < tickers.size(); i++) {
            String ticker = tickers.get(i);
            try {
                Model.Quote q = client.load(ticker);
                Model.Signal signal = SignalEngine.evaluate(q, store.minEdge());
                Model.Snapshot snapshot = new Model.Snapshot(q, signal, System.currentTimeMillis());
                String previous = store.previousStatus(ticker);
                store.saveSnapshot(snapshot);
                if ("BUY".equals(signal.status)) {
                    buys++;
                    if (!"BUY".equals(previous)) {
                        store.addHistory(ticker, q.price, "Новый сигнал «Брать»");
                        Notifier.send(context, snapshot);
                    }
                }
                ok++;
            } catch (Exception ex) {
                errors++;
                if (firstError.isEmpty()) firstError = ticker + ": " + ex.getMessage();
                // Ошибка сети не отменяет прошлый сигнал, но UI помечает время обновления.
            }
            if (progress != null) progress.onProgress(i + 1, tickers.size(), ticker);
        }
        store.setLastCheck(System.currentTimeMillis());
        return new Result(ok, errors, buys, firstError);
    }
}
