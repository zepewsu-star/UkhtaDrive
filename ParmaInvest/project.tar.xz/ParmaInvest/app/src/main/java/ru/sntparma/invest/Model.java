package ru.sntparma.invest;

import java.util.ArrayList;
import java.util.List;

public final class Model {
    private Model() { }

    public static final class Candle {
        public final String date;
        public final double close;

        public Candle(String date, double close) {
            this.date = date;
            this.close = close;
        }
    }

    public static final class Quote {
        public final String ticker;
        public final String name;
        public final double price;
        public final String date;
        public final List<Candle> candles;

        public Quote(String ticker, String name, double price, String date, List<Candle> candles) {
            this.ticker = ticker;
            this.name = name;
            this.price = price;
            this.date = date;
            this.candles = new ArrayList<>(candles);
        }
    }

    public static final class Signal {
        public final String status; // BUY, WAIT, NO_DATA
        public final String note;
        public final double entryPrice;
        public final int rank;

        public Signal(String status, String note, double entryPrice, int rank) {
            this.status = status;
            this.note = note;
            this.entryPrice = entryPrice;
            this.rank = rank;
        }
    }

    public static final class Snapshot {
        public final String ticker, name, date, status, note;
        public final double price, entryPrice;
        public final int rank;
        public final long fetchedAt;

        public Snapshot(Quote q, Signal signal, long time) {
            this(q.ticker, q.name, q.date, signal.status, signal.note, q.price,
                 signal.entryPrice, signal.rank, time);
        }

        public Snapshot(String ticker, String name, String date, String status,
                        String note, double price, double entryPrice, int rank, long fetchedAt) {
            this.ticker = ticker;
            this.name = name;
            this.date = date;
            this.status = status;
            this.note = note;
            this.price = price;
            this.entryPrice = entryPrice;
            this.rank = rank;
            this.fetchedAt = fetchedAt;
        }
    }
}
