package ru.sntparma.invest;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

/** Только локальные уведомления: приложение не подключено к FCM. */
public final class Notifier {
    private static final String CHANNEL = "buy_signals_v1";
    private Notifier() { }

    public static void ensureChannel(Context ctx) {
        NotificationManager manager = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null && Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Сигналы для входа",
                    NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Новые сигналы «Брать» по выбранным инструментам");
            manager.createNotificationChannel(ch);
        }
    }

    public static void send(Context ctx, Model.Snapshot s) {
        if (!new Store(ctx).notifyEnabled()) return;
        if (Build.VERSION.SDK_INT >= 33
                && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return;
        ensureChannel(ctx);
        NotificationManager manager = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        Intent open = new Intent(ctx, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent intent = PendingIntent.getActivity(ctx, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification notification = new android.app.Notification.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_chart)
                .setContentTitle("Проверить покупку: " + s.ticker)
                .setContentText("Появился сигнал «Брать» · " + MainActivity.price(s.price))
                .setStyle(new android.app.Notification.BigTextStyle().bigText(
                        s.name + " · " + s.note + ". Откройте приложение и проверьте цену у брокера."))
                .setContentIntent(intent)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .build();
        manager.notify(1000 + Math.abs(s.ticker.hashCode() % 100000), notification);
    }
}
