package ru.sntparma.invest;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** Данные Московской биржи ISS с задержкой. Только HTTPS, без брокерских ключей. */
public final class MoexClient {
    private static final String API = "https://iss.moex.com/iss/";
    private static final Pattern TICKER = Pattern.compile("[A-Z0-9]{1,12}");

    public Model.Quote load(String input) throws Exception {
        String ticker = input.toUpperCase(Locale.ROOT).trim();
        if (!TICKER.matcher(ticker).matches()) throw new IllegalArgumentException("Неверный тикер");
        SecurityDetails details = getDetails(ticker);
        String start = LocalDate.now().minusDays(118).toString();
        String end = LocalDate.now().toString();
        String base = "engines/stock/markets/shares/";
        String endpoint = details.board.isEmpty()
                ? base + "securities/" + ticker + "/candles.json"
                : base + "boards/" + details.board + "/securities/" + ticker + "/candles.json";
        List<Model.Candle> candles = fetchCandles(endpoint, start, end);
        if (candles.size() < 65 && !details.board.isEmpty()) {
            candles = fetchCandles(base + "securities/" + ticker + "/candles.json", start, end);
        }
        if (candles.isEmpty()) throw new IllegalStateException("Нет истории котировок");
        Model.Candle recent = candles.get(candles.size() - 1);
        double price = recent.close;
        if (!details.board.isEmpty()) {
            try {
                double marketLast = getMarketPrice(ticker, details.board);
                if (marketLast > 0) price = marketLast;
            } catch (Exception ignored) {
                // Историческая свеча остаётся допустимым запасным источником.
            }
        }
        return new Model.Quote(ticker, details.name.isEmpty() ? ticker : details.name,
                price, recent.date, candles);
    }

    private SecurityDetails getDetails(String ticker) throws Exception {
        JSONObject raw = fetch(API + "securities/" + ticker + ".json?iss.meta=off");
        JSONObject sec = raw.optJSONObject("description");
        String name = "";
        if (sec != null) {
            int keyCol = column(sec, "name");
            int valCol = column(sec, "value");
            JSONArray rows = sec.optJSONArray("data");
            if (keyCol >= 0 && valCol >= 0 && rows != null) {
                for (int i = 0; i < rows.length(); i++) {
                    JSONArray row = rows.optJSONArray(i);
                    if (row != null && ("SHORTNAME".equalsIgnoreCase(row.optString(keyCol))
                         || "NAME".equalsIgnoreCase(row.optString(keyCol))) && name.isEmpty()) {
                        name = row.optString(valCol, "");
                    }
                }
            }
        }
        JSONObject boards = raw.optJSONObject("boards");
        String board = "";
        if (boards != null) {
            JSONArray rows = boards.optJSONArray("data");
            int boardCol = column(boards, "boardid");
            int engineCol = column(boards, "engine");
            int marketCol = column(boards, "market");
            int primaryCol = column(boards, "is_primary");
            int tradedCol = column(boards, "is_traded");
            int best = -1;
            if (rows != null && boardCol >= 0) {
                for (int i = 0; i < rows.length(); i++) {
                    JSONArray row = rows.optJSONArray(i);
                    if (row == null) continue;
                    if (engineCol >= 0 && !"stock".equalsIgnoreCase(row.optString(engineCol))) continue;
                    if (marketCol >= 0 && !"shares".equalsIgnoreCase(row.optString(marketCol))) continue;
                    int score = (primaryCol >= 0 && row.optInt(primaryCol) == 1 ? 4 : 0)
                            + (tradedCol >= 0 && row.optInt(tradedCol) == 1 ? 2 : 0);
                    if (score > best) {
                        best = score;
                        board = row.optString(boardCol, "");
                    }
                }
            }
        }
        if (!TICKER.matcher(board).matches()) board = "";
        return new SecurityDetails(board, name);
    }

    private List<Model.Candle> fetchCandles(String path, String start, String end) throws Exception {
        String url = API + path + "?iss.meta=off&iss.only=candles&interval=24&from=" + start + "&till=" + end;
        JSONObject raw = fetch(url);
        JSONObject obj = raw.optJSONObject("candles");
        if (obj == null) return Collections.emptyList();
        int dateCol = column(obj, "begin");
        int closeCol = column(obj, "close");
        if (dateCol < 0 || closeCol < 0) return Collections.emptyList();
        JSONArray rows = obj.optJSONArray("data");
        if (rows == null) return Collections.emptyList();
        List<Model.Candle> list = new ArrayList<>();
        for (int i = 0; i < rows.length(); i++) {
            JSONArray r = rows.optJSONArray(i);
            if (r == null) continue;
            String day = r.optString(dateCol, "");
            if (day.length() < 10 || r.isNull(closeCol)) continue;
            double close = r.optDouble(closeCol, 0);
            if (Double.isFinite(close) && close > 0) {
                list.add(new Model.Candle(day.substring(0, 10), close));
            }
        }
        // У ISS свечи могут включать несколько сессий на одну дату. Оставляем последнюю.
        list.sort(Comparator.comparing(c -> c.date));
        List<Model.Candle> daily = new ArrayList<>();
        for (Model.Candle c : list) {
            if (!daily.isEmpty() && daily.get(daily.size() - 1).date.equals(c.date)) {
                daily.set(daily.size() - 1, c);
            } else daily.add(c);
        }
        return daily;
    }

    private double getMarketPrice(String ticker, String board) throws Exception {
        JSONObject raw = fetch(API + "engines/stock/markets/shares/boards/" + board
                + "/securities/" + ticker + ".json?iss.meta=off&iss.only=marketdata");
        JSONObject market = raw.optJSONObject("marketdata");
        if (market == null) return 0;
        JSONArray rows = market.optJSONArray("data");
        if (rows == null || rows.length() == 0) return 0;
        JSONArray row = rows.optJSONArray(0);
        if (row == null) return 0;
        for (String key : new String[]{"LAST", "MARKETPRICE", "LCURRENTPRICE"}) {
            int idx = column(market, key);
            if (idx >= 0 && !row.isNull(idx)) {
                double price = row.optDouble(idx, 0);
                if (price > 0 && Double.isFinite(price)) return price;
            }
        }
        return 0;
    }

    private static int column(JSONObject section, String name) {
        JSONArray cols = section.optJSONArray("columns");
        if (cols == null) return -1;
        for (int i = 0; i < cols.length(); i++) {
            if (name.equalsIgnoreCase(cols.optString(i, ""))) return i;
        }
        return -1;
    }

    private static JSONObject fetch(String link) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(link).openConnection();
        conn.setConnectTimeout(12000);
        conn.setReadTimeout(12000);
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("User-Agent", "ParmaInvest/1.0 (personal informational app)");
        try {
            int responseCode = conn.getResponseCode();
            if (responseCode != 200) throw new java.io.IOException("MOEX HTTP " + responseCode);
            StringBuilder result = new StringBuilder();
            try (BufferedReader in = new BufferedReader(new InputStreamReader(
                    conn.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = in.readLine()) != null) {
                    result.append(line);
                    if (result.length() > 3_000_000) throw new java.io.IOException("Слишком большой ответ");
                }
            }
            return new JSONObject(result.toString());
        } finally {
            conn.disconnect();
        }
    }

    private static final class SecurityDetails {
        final String board;
        final String name;
        SecurityDetails(String board, String name) { this.board = board; this.name = name; }
    }
}
