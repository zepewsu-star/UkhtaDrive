package ru.sntparma.invest;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Нативный интерфейс, без WebView, рекламы, брокерских API и внешних библиотек. */
public final class MainActivity extends Activity {
    private static final int INK = Color.rgb(23, 35, 52);
    private static final int MUTED = Color.rgb(105, 120, 138);
    private static final int TEAL = Color.rgb(10, 117, 107);
    private static final int CLOUD = Color.rgb(246, 248, 251);
    private static final int LINE = Color.rgb(228, 234, 240);
    private static final int POSITIVE = Color.rgb(3, 118, 87);
    private static final int WARNING = Color.rgb(161, 107, 12);
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private LinearLayout root;
    private FrameLayout screen;
    private Store store;
    private int tab = 0;
    private String progressText = "";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(CLOUD);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        store = new Store(this);
        Notifier.ensureChannel(this);
        SignalScheduler.apply(this);
        buildShell();
        render();
        if (Build.VERSION.SDK_INT >= 33 && !store.notificationPrompted()) {
            store.markNotificationPrompted();
            main.postDelayed(this::permission, 650);
        }
        if (store.lastCheck() == 0 || System.currentTimeMillis() - store.lastCheck() > 20 * 60_000L) {
            refresh();
        }
    }

    @Override protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(CLOUD);
        setContentView(root);

        LinearLayout heading = new LinearLayout(this);
        heading.setOrientation(LinearLayout.HORIZONTAL);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.setPadding(dp(22), dp(14), dp(16), dp(13));
        heading.setBackgroundColor(CLOUD);
        root.addView(heading);

        LinearLayout titleArea = new LinearLayout(this);
        titleArea.setOrientation(LinearLayout.VERTICAL);
        heading.addView(titleArea, new LinearLayout.LayoutParams(0, -2, 1));
        TextView brand = label("ПАРМА  /  ИНВЕСТ", 12, TEAL, true);
        brand.setLetterSpacing(0.12f);
        titleArea.addView(brand);
        titleArea.addView(label("Инвестиционные сигналы", 22, INK, true));

        TextView refresh = label("↻", 30, TEAL, false);
        refresh.setGravity(Gravity.CENTER);
        refresh.setBackground(rounded(Color.WHITE, 15, LINE));
        heading.addView(refresh, new LinearLayout.LayoutParams(dp(48), dp(48)));
        refresh.setOnClickListener(v -> refresh());
        refresh.setContentDescription("Обновить котировки");

        screen = new FrameLayout(this);
        root.addView(screen, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setPadding(dp(8), dp(7), dp(8), dp(8));
        nav.setBackgroundColor(Color.WHITE);
        String[] labels = {"Сигналы", "Портфель", "История", "Настройки"};
        for (int i = 0; i < labels.length; i++) {
            final int selected = i;
            TextView item = label(labels[i], 12, i == tab ? TEAL : MUTED, i == tab);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(2), dp(11), dp(2), dp(11));
            nav.addView(item, new LinearLayout.LayoutParams(0, -2, 1));
            item.setOnClickListener(v -> { tab = selected; buildShell(); render(); });
            if (i == tab) item.setBackground(rounded(Color.rgb(226, 244, 240), 12, 0));
        }
        root.addView(nav);
    }

    private void render() {
        screen.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        screen.addView(scroll);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(5), dp(18), dp(26));
        scroll.addView(body);
        switch (tab) {
            case 0: showSignals(body); break;
            case 1: showPortfolio(body); break;
            case 2: showHistory(body); break;
            default: showSettings(body); break;
        }
    }

    private void showSignals(LinearLayout body) {
        Map<String, Model.Snapshot> byTicker = store.snapshots();
        List<Model.Snapshot> all = new ArrayList<>();
        int buys = 0, valid = 0;
        for (String ticker : store.tickers()) {
            Model.Snapshot s = byTicker.get(ticker);
            if (s == null) s = new Model.Snapshot(ticker, friendlyName(ticker), "", "NO_DATA",
                    "Ожидается первая загрузка", 0, 0, 0, 0);
            if (isFresh(s) && "BUY".equals(s.status)) buys++;
            if (isFresh(s) && !"NO_DATA".equals(s.status)) valid++;
            all.add(s);
        }
        all.sort(Comparator.<Model.Snapshot>comparingInt(s ->
                isFresh(s) && "BUY".equals(s.status) ? 0 :
                isFresh(s) && "WAIT".equals(s.status) ? 1 : 2)
                .thenComparing((a, b) -> Integer.compare(b.rank, a.rank)));

        LinearLayout hero = panel(Color.WHITE);
        TextView eyebrow = label("ТЕКУЩАЯ СИТУАЦИЯ", 12, MUTED, true);
        eyebrow.setLetterSpacing(0.08f);
        hero.addView(eyebrow);
        TextView mainLine = label(buys > 0 ? "Есть " + buys + " сигнал(ов)" :
                (valid > 0 ? "Сейчас лучше подождать" : "Проверяем рынок"), 23,
                buys > 0 ? POSITIVE : INK, true);
        marginTop(hero, mainLine, 8);
        String text = buys > 0
                ? "Сигналы — не гарантия дохода. Проверьте цену перед сделкой."
                : "Не покупаем просто ради покупки. Ждём условий для разумного входа.";
        marginTop(hero, label(text, 14, MUTED, false), 8);
        String checkText = busy.get() ? progressText :
                store.lastCheck() == 0 ? "Данных ещё нет" : "Проверено " + time(store.lastCheck());
        marginTop(hero, label(checkText, 12, TEAL, false), 14);
        addBottom(body, hero, 17);

        LinearLayout section = new LinearLayout(this);
        section.setGravity(Gravity.CENTER_VERTICAL);
        section.addView(label("Инструменты", 19, INK, true), new LinearLayout.LayoutParams(0, -2, 1));
        TextView add = label("+ Добавить", 14, TEAL, true);
        add.setPadding(dp(10), dp(8), dp(2), dp(8));
        section.addView(add);
        add.setOnClickListener(v -> addTicker());
        addBottom(body, section, 10);

        for (Model.Snapshot s : all) {
            LinearLayout card = panel(Color.WHITE);
            LinearLayout header = new LinearLayout(this);
            header.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout titleGroup = new LinearLayout(this);
            titleGroup.setOrientation(LinearLayout.VERTICAL);
            titleGroup.addView(label(s.ticker, 19, INK, true));
            TextView name = label(shorten(s.name), 12, MUTED, false);
            marginTop(titleGroup, name, 2);
            header.addView(titleGroup, new LinearLayout.LayoutParams(0, -2, 1));
            String status = visibleStatus(s);
            TextView stateLabel = label("BUY".equals(status) ? "БРАТЬ" :
                    "WAIT".equals(status) ? "ПОДОЖДАТЬ" : "НЕТ ДАННЫХ", 11,
                    "BUY".equals(status) ? POSITIVE : "WAIT".equals(status) ? WARNING : MUTED, true);
            stateLabel.setPadding(dp(10), dp(7), dp(10), dp(7));
            stateLabel.setBackground(rounded("BUY".equals(status) ? Color.rgb(225, 246, 235) :
                    "WAIT".equals(status) ? Color.rgb(255, 246, 220) : CLOUD, 12, 0));
            header.addView(stateLabel);
            card.addView(header);
            TextView priceText = label(s.price > 0 ? price(s.price) : "—", 26, INK, true);
            marginTop(card, priceText, 14);
            marginTop(card, label(s.note.isEmpty() ? "Ожидаем данные" : s.note, 13, MUTED, false), 5);
            if ("WAIT".equals(status) && s.entryPrice > 0) {
                marginTop(card, label("Ориентир для повторной оценки: " + price(s.entryPrice),
                        13, TEAL, true), 9);
            }
            if (s.price > 0) marginTop(card, label("Биржевые данные: " + s.date, 11, MUTED, false), 11);
            final Model.Snapshot asset = s;
            card.setOnClickListener(v -> detail(asset));
            card.setOnLongClickListener(v -> { confirmRemoveTicker(asset.ticker); return true; });
            addBottom(body, card, 11);
        }
        marginTop(body, label("Данные MOEX ISS могут поступать с задержкой. «Брать» — алгоритмический сигнал, а не распоряжение на покупку.",
                12, MUTED, false), 9);
    }

    private void showPortfolio(LinearLayout body) {
        List<Store.Position> positions = store.positions();
        Map<String, Model.Snapshot> snaps = store.snapshots();
        double invested = 0, value = 0;
        for (Store.Position p : positions) {
            invested += p.quantity * p.average;
            Model.Snapshot s = snaps.get(p.ticker);
            value += p.quantity * (s == null || s.price <= 0 ? p.average : s.price);
        }
        LinearLayout hero = panel(Color.WHITE);
        hero.addView(label("МОЙ ПОРТФЕЛЬ", 12, MUTED, true));
        marginTop(hero, label(positions.isEmpty() ? "Нет позиций" : price(value), 26, INK, true), 10);
        if (!positions.isEmpty()) {
            double delta = value - invested;
            marginTop(hero, label("Результат по введённым позициям: "
                    + (delta > 0 ? "+" : "") + price(delta), 14,
                    delta >= 0 ? POSITIVE : Color.rgb(190, 70, 70), true), 7);
            marginTop(hero, label("Без учёта комиссий, налогов и денежных остатков", 12, MUTED, false), 7);
        } else {
            marginTop(hero, label("Можно вручную указать количество паёв/акций и среднюю цену покупки.",
                    14, MUTED, false), 8);
        }
        addBottom(body, hero, 17);
        Button add = action("+ Добавить позицию");
        add.setOnClickListener(v -> editPosition(null));
        addBottom(body, add, 14);
        for (Store.Position p : positions) {
            Model.Snapshot s = snaps.get(p.ticker);
            double current = s == null || s.price <= 0 ? 0 : s.price;
            LinearLayout card = panel(Color.WHITE);
            card.addView(label(p.ticker, 18, INK, true));
            marginTop(card, label("Количество: " + decimal(p.quantity) + " · Средняя покупка: " + price(p.average),
                    13, MUTED, false), 7);
            marginTop(card, label(current > 0 ? "Последняя цена: " + price(current) : "Нет доступной цены",
                    13, MUTED, false), 4);
            if (current > 0) {
                double delta = (current - p.average) * p.quantity;
                marginTop(card, label("Результат: " + (delta > 0 ? "+" : "") + price(delta), 15,
                        delta >= 0 ? POSITIVE : Color.rgb(190, 70, 70), true), 10);
            }
            card.setOnClickListener(v -> editPosition(p));
            addBottom(body, card, 10);
        }
    }

    private void showHistory(LinearLayout body) {
        marginTop(body, label("История сигналов", 22, INK, true), 5);
        marginTop(body, label("Здесь сохраняются новые переходы к статусу «Брать». Ожидание не создаёт запись.",
                13, MUTED, false), 8);
        List<Store.HistoryRow> events = store.history();
        if (events.isEmpty()) {
            LinearLayout empty = panel(Color.WHITE);
            empty.addView(label("Пока сигналов нет", 19, INK, true));
            marginTop(empty, label("При первом появлении сигнала запись возникнет здесь.",
                    14, MUTED, false), 8);
            marginTop(body, empty, 18);
        }
        for (Store.HistoryRow event : events) {
            LinearLayout card = panel(Color.WHITE);
            card.addView(label(event.ticker + " · " + event.text, 16, INK, true));
            marginTop(card, label(time(event.at) + " · " + price(event.price), 13, MUTED, false), 8);
            marginTop(body, card, 11);
        }
    }

    private void showSettings(LinearLayout body) {
        marginTop(body, label("Настройки", 22, INK, true), 5);
        marginTop(body, label("Анализируем рынок без подключения к брокерскому счёту.",
                13, MUTED, false), 8);
        setting(body, "Мониторинг", store.monitoringEnabled() ? "Включён" : "Приостановлен",
                () -> {
                    store.setMonitoringEnabled(!store.monitoringEnabled());
                    SignalScheduler.apply(this);
                    render();
                });
        setting(body, "Частота фоновой проверки", store.intervalMinutes() + " минут (примерно)",
                () -> new AlertDialog.Builder(this).setTitle("Частота проверки")
                    .setSingleChoiceItems(new String[]{"15 минут", "30 минут", "60 минут"},
                        store.intervalMinutes() == 15 ? 0 : store.intervalMinutes() == 30 ? 1 : 2,
                        (dialog, n) -> {
                            store.setIntervalMinutes(new int[]{15, 30, 60}[n]);
                            SignalScheduler.apply(this);
                            dialog.dismiss(); render();
                        }).setNegativeButton("Отмена", null).show());
        setting(body, "Минимальный запас по условиям", store.edgePercent() + "% (эвристика)",
                () -> new AlertDialog.Builder(this).setTitle("Минимальный запас")
                    .setSingleChoiceItems(new String[]{"6% — стандартно", "8% — осторожнее", "10% — строго"},
                        store.edgePercent() == 6 ? 0 : store.edgePercent() == 8 ? 1 : 2,
                        (dialog, n) -> {store.setEdgePercent(new int[]{6, 8, 10}[n]);
                            dialog.dismiss(); refresh(); })
                    .setNegativeButton("Отмена", null).show());
        setting(body, "Уведомления о новых сигналах",
                store.notifyEnabled() ? "Включены в приложении" : "Выключены",
                () -> {
                    store.setNotifyEnabled(!store.notifyEnabled());
                    if (store.notifyEnabled()) permission();
                    render();
                });
        setting(body, "Разрешение на уведомления", "Открыть запрос доступа",
                this::permission);
        LinearLayout disclaimer = panel(Color.WHITE);
        disclaimer.addView(label("Как работает приложение", 17, INK, true));
        marginTop(disclaimer, label("Использует последние дневные свечи и котировки Московской биржи. "
                + "По каждому инструменту проверяет направление рынка, импульс, перегрев, колебания цены "
                + "и запас относительно условных издержек. Правила могут давать ошибочные сигналы.",
                13, MUTED, false), 9);
        marginTop(disclaimer, label("Фоновые проверки выполняет Android. HyperOS вправе откладывать "
                + "их ради экономии батареи. Для непрерывного независимого мониторинга нужен сервер и push.",
                13, MUTED, false), 10);
        marginTop(disclaimer, label("Никаких автоматических сделок. Нет доступа к деньгам и брокерскому счёту.",
                13, TEAL, true), 10);
        marginTop(body, disclaimer, 14);
    }

    private void setting(LinearLayout body, String heading, String value, Runnable action) {
        LinearLayout row = panel(Color.WHITE);
        row.addView(label(heading, 15, INK, true));
        marginTop(row, label(value + "   ›", 13, MUTED, false), 5);
        row.setOnClickListener(v -> action.run());
        marginTop(body, row, 11);
    }

    private void detail(Model.Snapshot s) {
        String text = s.name + "\n\nПоследняя цена: " + (s.price > 0 ? price(s.price) : "нет данных")
                + "\nРешение: " + ("BUY".equals(visibleStatus(s)) ? "БРАТЬ" :
                        "WAIT".equals(visibleStatus(s)) ? "ПОДОЖДАТЬ" : "НЕТ ДАННЫХ")
                + "\n" + s.note + "\n\nДата котировки: " + (s.date.isEmpty() ? "—" : s.date)
                + (s.entryPrice > 0 ? "\nОриентир: " + price(s.entryPrice) : "")
                + "\n\nАлгоритм не предсказывает будущее и не заменяет проверку условий сделки.";
        new AlertDialog.Builder(this).setTitle(s.ticker).setMessage(text)
                .setPositiveButton("Понятно", null).show();
    }

    private void addTicker() {
        EditText entry = new EditText(this);
        entry.setSingleLine(true);
        entry.setHint("Например, SBER");
        entry.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        LinearLayout holder = new LinearLayout(this);
        holder.setPadding(dp(22), dp(8), dp(22), dp(8));
        holder.addView(entry, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this).setTitle("Добавить тикер MOEX")
                .setView(holder).setPositiveButton("Добавить", (d, w) -> {
                    String t = entry.getText().toString().trim().toUpperCase(Locale.ROOT);
                    if (!t.matches("[A-Z0-9]{1,12}")) {
                        toast("Введите корректный биржевой тикер"); return;
                    }
                    List<String> list = store.tickers();
                    if (list.contains(t)) {toast("Тикер уже добавлен"); return;}
                    if (list.size() >= 20) {toast("Не более 20 инструментов"); return;}
                    list.add(t);
                    store.saveTickers(list);
                    render(); refresh();
                }).setNegativeButton("Отмена", null).show();
    }

    private void confirmRemoveTicker(String ticker) {
        new AlertDialog.Builder(this).setTitle("Убрать " + ticker + " из наблюдения?")
                .setMessage("Позиция портфеля, если она есть, останется.")
                .setPositiveButton("Убрать", (d, w) -> {
                    List<String> list = store.tickers();
                    list.remove(ticker);
                    store.saveTickers(list);
                    render();
                }).setNegativeButton("Отмена", null).show();
    }

    private void editPosition(Store.Position pos) {
        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);
        fields.setPadding(dp(22), dp(10), dp(22), dp(3));
        EditText tickerField = new EditText(this);
        tickerField.setSingleLine(true);
        tickerField.setHint("Тикер (GOLD)");
        tickerField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        if (pos != null) {tickerField.setText(pos.ticker); tickerField.setEnabled(false);}
        fields.addView(tickerField);
        EditText quantity = new EditText(this);
        quantity.setSingleLine(true);
        quantity.setHint("Количество, например 100");
        quantity.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        if (pos != null) quantity.setText(decimal(pos.quantity));
        fields.addView(quantity);
        EditText average = new EditText(this);
        average.setSingleLine(true);
        average.setHint("Средняя цена покупки, ₽");
        average.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        if (pos != null) average.setText(decimal(pos.average));
        fields.addView(average);
        AlertDialog.Builder box = new AlertDialog.Builder(this)
                .setTitle(pos == null ? "Добавить позицию" : "Изменить позицию")
                .setView(fields).setNegativeButton("Отмена", null);
        if (pos != null) box.setNeutralButton("Удалить", (d, w) -> {
            store.savePosition(pos.ticker, 0, 0); render();
        });
        AlertDialog dialog = box.setPositiveButton("Сохранить", null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String ticker = tickerField.getText().toString().trim().toUpperCase(Locale.ROOT);
            if (!ticker.matches("[A-Z0-9]{1,12}")) {tickerField.setError("Неверный тикер"); return;}
            try {
                double qty = Double.parseDouble(quantity.getText().toString().replace(',', '.'));
                double avg = Double.parseDouble(average.getText().toString().replace(',', '.'));
                if (!Double.isFinite(qty) || !Double.isFinite(avg) || qty <= 0 || avg <= 0) {
                    toast("Количество и цена должны быть больше нуля"); return;
                }
                store.savePosition(ticker, qty, avg);
                List<String> list = store.tickers();
                if (!list.contains(ticker) && list.size() < 20) {list.add(ticker); store.saveTickers(list);}
                dialog.dismiss(); render(); refresh();
            } catch (NumberFormatException ex) {
                toast("Укажите число для количества и цены");
            }
        }));
        dialog.show();
    }

    private void refresh() {
        if (!busy.compareAndSet(false, true)) {toast("Проверка уже выполняется"); return;}
        progressText = "Загружаю данные Московской биржи…";
        render();
        executor.execute(() -> {
            UpdateEngine.Result result = UpdateEngine.run(getApplicationContext(), (done, total, ticker) -> {
                progressText = "Проверено " + done + " из " + total;
                main.post(() -> { if (!isFinishing() && tab == 0) render(); });
            });
            main.post(() -> {
                busy.set(false);
                if (isFinishing() || isDestroyed()) return;
                progressText = "";
                render();
                if (result.errors > 0) {
                    toast("Загружено: " + result.ok + ". Ошибок: " + result.errors
                            + (result.firstError.isEmpty() ? "" : ". " + result.firstError));
                }
            });
        });
    }

    private void permission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
            } else toast("Уведомления уже разрешены");
        } else toast("На этой версии Android уведомления включаются в настройках системы");
    }

    private String visibleStatus(Model.Snapshot s) {
        return isFresh(s) ? s.status : "NO_DATA";
    }
    private boolean isFresh(Model.Snapshot s) {
        return s.fetchedAt > 0 && System.currentTimeMillis() - s.fetchedAt < 3 * 60 * 60_000L;
    }
    private static String friendlyName(String ticker) {
        switch (ticker) {
            case "GOLD": return "ВИМ — Золото";
            case "SBER": return "Сбербанк";
            case "LKOH": return "Лукойл";
            case "TMOS": return "Фонд на индекс Мосбиржи";
            case "SBMX": return "Фонд на индекс Мосбиржи";
            case "YDEX": return "Яндекс";
            default: return ticker;
        }
    }
    private String shorten(String name) { return name.length() > 42 ? name.substring(0, 39) + "…" : name; }

    private int dp(float dp) { return (int) (getResources().getDisplayMetrics().density * dp + 0.5f); }
    private static String decimal(double number) {
        return String.format(Locale.US, number == Math.rint(number) ? "%.0f" : "%.4f", number);
    }
    public static String price(double amount) {
        return String.format(new Locale("ru", "RU"), Math.abs(amount) < 10 && amount != 0 ? "%.4f ₽" : "%.2f ₽", amount);
    }
    private static String time(long ms) {
        return ms <= 0 ? "—" : new SimpleDateFormat("dd.MM.yyyy HH:mm", new Locale("ru", "RU"))
                .format(new Date(ms));
    }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    private TextView label(String text, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setLineSpacing(dp(2), 1f);
        return v;
    }
    private GradientDrawable rounded(int bg, int radius, int borderColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(radius));
        if (borderColor != 0) g.setStroke(dp(1), borderColor);
        return g;
    }
    private LinearLayout panel(int color) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(17), dp(16), dp(17));
        card.setBackground(rounded(color, 16, LINE));
        return card;
    }
    private void marginTop(LinearLayout container, View v, int dpTop) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(dpTop);
        container.addView(v, lp);
    }
    private void addBottom(LinearLayout container, View v, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(bottom);
        container.addView(v, lp);
    }
    private Button action(String title) {
        Button button = new Button(this);
        button.setText(title);
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setBackground(rounded(TEAL, 14, 0));
        button.setPadding(dp(10), dp(11), dp(10), dp(11));
        return button;
    }
}
