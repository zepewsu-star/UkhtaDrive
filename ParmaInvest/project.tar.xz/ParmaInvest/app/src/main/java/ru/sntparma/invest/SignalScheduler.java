package ru.sntparma.invest;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;

/** JobScheduler вместо вечного фонового процесса (интервал ОС вправе сдвигать). */
public final class SignalScheduler {
    private static final int JOB_ID = 90423;
    private SignalScheduler() { }

    public static void apply(Context ctx) {
        JobScheduler scheduler = (JobScheduler) ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler == null) return;
        scheduler.cancel(JOB_ID);
        Store store = new Store(ctx);
        if (!store.monitoringEnabled()) return;
        long millis = Math.max(15, store.intervalMinutes()) * 60_000L;
        JobInfo job = new JobInfo.Builder(JOB_ID, new ComponentName(ctx, SignalJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setPeriodic(millis)
                .build();
        scheduler.schedule(job);
    }
}
