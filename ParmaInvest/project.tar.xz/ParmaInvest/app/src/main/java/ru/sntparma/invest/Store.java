package ru.sntparma.invest;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Locale;
import java.util.Set;

/** Локальное состояние приложения; никаких паролей и брокерских данных. */
public final class Store {
    private static final String PREFS = "parma_invest_v1";
    private final SharedPreferences p;

    public Store(Context context) {
        p = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public List<String> tickers() {
        String raw = p.getString("tickers", "GOLD,SBER,LKOH,TMOS,SBMX,YDEX");
        Set<String> set = new LinkedHashSet<>();
        for (String t : raw.split(",")) {
            t = t.trim().toUpperCase(Locale.ROOT);
            if (t.matches("[A-Z0-9]{1,12}")) set.add(t);
        }
        return new ArrayList<>(set);
    }

    public void saveTickers(List<String> tickers) {
        p.edit().putString("tickers", String.join(",", tickers)).apply();
    }

    public int intervalMinutes() { return p.getInt("interval", 30); }
    public void setIntervalMinutes(int m) { p.edit().putInt("interval", m).apply(); }
    public double minEdge() { return p.getInt("edge", 6) / 100.0; }
    public int edgePercent() { return p.getInt("edge", 6); }
    public void setEdgePercent(int percent) { p.edit().putInt("edge", percent).apply(); }
    public boolean notificationPrompted() { return p.getBoolean("notif_asked", false); }
    public void markNotificationPrompted() { p.edit().putBoolean("notif_asked", true).apply(); }
    public boolean notifyEnabled() { return p.getBoolean("notifications", true); }
    public void setNotifyEnabled(boolean enabled) { p.edit().putBoolean("notifications", enabled).apply(); }
    public boolean monitoringEnabled() { return p.getBoolean("monitoring", true); }
    public void setMonitoringEnabled(boolean enabled) { p.edit().putBoolean("monitoring", enabled).apply(); }
    public long lastCheck() { return p.getLong("last_check", 0L); }
    public void setLastCheck(long when) { p.edit().putLong("last_check", when).apply(); }

    public synchronized Map<String, Model.Snapshot> snapshots() {
        Map<String, Model.Snapshot> output = new HashMap<>();
        try {
            JSONObject object = new JSONObject(p.getString("snapshots", "{}"));
            for (String ticker : tickers()) {
                JSONObject o = object.optJSONObject(ticker);
                if (o == null) continue;
                output.put(ticker, new Model.Snapshot(
                    ticker, o.optString("name", ticker), o.optString("date", ""),
                    o.optString("status", "NO_DATA"), o.optString("note", ""),
                    o.optDouble("price", 0), o.optDouble("entry", 0),
                    o.optInt("rank", 0), o.optLong("at", 0)));
            }
        } catch (Exception ignored) { }
        return output;
    }

    public synchronized String previousStatus(String ticker) {
        Model.Snapshot s = snapshots().get(ticker);
        return s == null ? "" : s.status;
    }

    public synchronized void saveSnapshot(Model.Snapshot s) {
        try {
            JSONObject obj = new JSONObject(p.getString("snapshots", "{}"));
            JSONObject row = new JSONObject();
            row.put("name", s.name);
            row.put("date", s.date);
            row.put("status", s.status);
            row.put("note", s.note);
            row.put("price", s.price);
            row.put("entry", s.entryPrice);
            row.put("rank", s.rank);
            row.put("at", s.fetchedAt);
            obj.put(s.ticker, row);
            p.edit().putString("snapshots", obj.toString()).commit();
        } catch (Exception ignored) { }
    }

    public synchronized void addHistory(String ticker, double price, String description) {
        try {
            JSONArray old = new JSONArray(p.getString("history", "[]"));
            JSONArray result = new JSONArray();
            JSONObject newRow = new JSONObject();
            newRow.put("ticker", ticker);
            newRow.put("price", price);
            newRow.put("text", description);
            newRow.put("at", System.currentTimeMillis());
            result.put(newRow);
            for (int i = 0; i < Math.min(149, old.length()); i++) result.put(old.get(i));
            p.edit().putString("history", result.toString()).commit();
        } catch (Exception ignored) { }
    }

    public synchronized List<HistoryRow> history() {
        List<HistoryRow> list = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p.getString("history", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null) list.add(new HistoryRow(o.optString("ticker"),
                        o.optString("text"), o.optDouble("price"), o.optLong("at")));
            }
        } catch (Exception ignored) { }
        return list;
    }


    public synchronized List<Position> positions() {
        List<Position> rows = new ArrayList<>();
        try {
            JSONObject all = new JSONObject(p.getString("positions", "{}"));
            for (java.util.Iterator<String> it = all.keys(); it.hasNext();) {
                String ticker = it.next();
                JSONObject x = all.optJSONObject(ticker);
                if (x == null) continue;
                double qty = x.optDouble("quantity", 0);
                double cost = x.optDouble("average", 0);
                if (qty > 0 && cost > 0) rows.add(new Position(ticker, qty, cost));
            }
        } catch (Exception ignored) { }
        rows.sort((a, b) -> a.ticker.compareTo(b.ticker));
        return rows;
    }

    public synchronized void savePosition(String ticker, double quantity, double averagePrice) {
        try {
            JSONObject all = new JSONObject(p.getString("positions", "{}"));
            if (quantity <= 0 || averagePrice <= 0) {
                all.remove(ticker);
            } else {
                JSONObject row = new JSONObject();
                row.put("quantity", quantity);
                row.put("average", averagePrice);
                all.put(ticker, row);
            }
            p.edit().putString("positions", all.toString()).commit();
        } catch (Exception ignored) { }
    }

    public static final class Position {
        public final String ticker;
        public final double quantity, average;
        public Position(String ticker, double quantity, double average) {
            this.ticker = ticker;
            this.quantity = quantity;
            this.average = average;
        }
    }

    public static final class HistoryRow {
        public final String ticker, text;
        public final double price;
        public final long at;
        public HistoryRow(String ticker, String text, double price, long at) {
            this.ticker = ticker;
            this.text = text;
            this.price = price;
            this.at = at;
        }
    }
}
