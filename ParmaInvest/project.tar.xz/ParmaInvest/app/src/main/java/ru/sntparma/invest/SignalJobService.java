package ru.sntparma.invest;

import android.app.job.JobParameters;
import android.app.job.JobService;
import java.util.concurrent.atomic.AtomicBoolean;

public final class SignalJobService extends JobService {
    private final AtomicBoolean cancelled = new AtomicBoolean(false);

    @Override public boolean onStartJob(JobParameters parameters) {
        cancelled.set(false);
        new Thread(() -> {
            try {
                if (!cancelled.get() && new Store(this).monitoringEnabled()) {
                    UpdateEngine.run(getApplicationContext(), null);
                }
            } finally {
                if (!cancelled.get()) jobFinished(parameters, false);
            }
        }, "MOEX-Signal-Job").start();
        return true;
    }

    @Override public boolean onStopJob(JobParameters parameters) {
        cancelled.set(true);
        return true;
    }
}
