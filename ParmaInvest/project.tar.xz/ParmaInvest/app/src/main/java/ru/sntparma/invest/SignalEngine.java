package ru.sntparma.invest;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * Прозрачный фильтр условий для входа, НЕ модель прогноза доходности.
 * Не выводит уверенность как вероятность прибыли и не делает сделки.
 */
public final class SignalEngine {
    private SignalEngine() { }

    public static Model.Signal evaluate(Model.Quote quote, double minimumEdge) {
        List<Model.Candle> c = quote.candles;
        int n = c.size();
        if (n < 65 || quote.price <= 0) {
            return new Model.Signal("NO_DATA", "Недостаточно биржевых данных", 0, 0);
        }
        try {
            LocalDate end = LocalDate.parse(quote.date.substring(0, 10));
            if (ChronoUnit.DAYS.between(end, LocalDate.now()) > 7) {
                return new Model.Signal("NO_DATA", "Биржевые данные устарели", 0, 0);
            }
        } catch (RuntimeException e) {
            return new Model.Signal("NO_DATA", "Дата котировки не определена", 0, 0);
        }
        double last = quote.price;
        double sma20 = avg(c, n - 20, n);
        double sma50 = avg(c, n - 50, n);
        double prev20 = c.get(n - 21).close;
        double prev60 = c.get(n - 61).close;
        if (sma20 <= 0 || sma50 <= 0 || prev20 <= 0 || prev60 <= 0) {
            return new Model.Signal("NO_DATA", "Ошибка значений цены", 0, 0);
        }
        double ret20 = last / prev20 - 1;
        double ret60 = last / prev60 - 1;
        double trend = sma20 / sma50 - 1;
        double rsi = rsi(c, 14);
        double volatility = volatility(c, 20);
        // Простая оценка запаса по прошлой динамике, НЕ прогноз будущего результата.
        double edgeEvidence = 0.55 * Math.max(0, ret60)
                + 0.35 * Math.max(0, ret20) + 0.10 * Math.max(0, trend);
        boolean healthyTrend = sma20 > sma50 && last > sma50 && ret60 > 0.03 && ret20 > 0;
        boolean sensiblePrice = last <= sma20 * 1.025 && last >= sma20 * 0.97;
        boolean sensibleMomentum = rsi >= 38 && rsi <= 64;
        boolean riskInBounds = volatility < 0.50;
        // Учитываем приблизительно 0.3% совокупных издержек покупки/продажи.
        boolean sufficientEdge = edgeEvidence > minimumEdge + 0.003;
        int rank = (int) Math.max(0, Math.min(100, Math.round(
                50 + ret60 * 140 + ret20 * 80 + trend * 150 - volatility * 24)));

        if (healthyTrend && sensiblePrice && sensibleMomentum && riskInBounds && sufficientEdge) {
            return new Model.Signal("BUY", "Условия для осторожного входа совпали", last, rank);
        }
        if (!healthyTrend) {
            return new Model.Signal("WAIT", "Пока нет устойчивого восходящего тренда", 0, rank);
        }
        if (!riskInBounds) {
            return new Model.Signal("WAIT", "Слишком сильные колебания цены", 0, rank);
        }
        if (!sufficientEdge) {
            return new Model.Signal("WAIT", "Недостаточный запас относительно риска и издержек", 0, rank);
        }
        if (rsi > 64 || last > sma20 * 1.025) {
            return new Model.Signal("WAIT", "Цена выросла слишком быстро; лучше дождаться отката",
                    Math.min(last * 0.99, sma20 * 1.005), rank);
        }
        return new Model.Signal("WAIT", "Вход пока не подтверждён", 0, rank);
    }

    private static double avg(List<Model.Candle> c, int from, int to) {
        double sum = 0;
        for (int i = from; i < to; i++) sum += c.get(i).close;
        return sum / (to - from);
    }

    private static double rsi(List<Model.Candle> c, int period) {
        int n = c.size();
        double gains = 0, losses = 0;
        for (int i = n - period; i < n; i++) {
            double d = c.get(i).close - c.get(i - 1).close;
            gains += Math.max(0, d);
            losses += Math.max(0, -d);
        }
        if (losses == 0) return gains == 0 ? 50 : 100;
        double rs = gains / losses;
        return 100 - (100 / (1 + rs));
    }

    private static double volatility(List<Model.Candle> c, int days) {
        int n = c.size();
        double mean = 0;
        for (int i = n - days; i < n; i++) {
            double prev = c.get(i - 1).close;
            if (prev <= 0) return Double.POSITIVE_INFINITY;
            mean += c.get(i).close / prev - 1;
        }
        mean /= days;
        double sumSq = 0;
        for (int i = n - days; i < n; i++) {
            double d = c.get(i).close / c.get(i - 1).close - 1 - mean;
            sumSq += d * d;
        }
        return Math.sqrt(sumSq / days) * Math.sqrt(252);
    }
}
