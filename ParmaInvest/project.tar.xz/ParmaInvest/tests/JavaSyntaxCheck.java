import com.sun.source.util.JavacTask;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import java.io.File;
import java.util.Arrays;

public class JavaSyntaxCheck {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> report = new DiagnosticCollector<>();
        try (StandardJavaFileManager mgr = compiler.getStandardFileManager(report, null, null)) {
            File src = new File("app/src/main/java/ru/sntparma/invest");
            File[] files = src.listFiles((d, n) -> n.endsWith(".java"));
            if (files == null) throw new IllegalStateException("No sources");
            JavacTask task = (JavacTask) compiler.getTask(null, mgr, report,
                    Arrays.asList("-proc:none"), null, mgr.getJavaFileObjects(files));
            task.parse();
            boolean error = false;
            for (Diagnostic<? extends JavaFileObject> d : report.getDiagnostics()) {
                if (d.getKind() == Diagnostic.Kind.ERROR) {
                    System.err.println(d); error = true;
                }
            }
            if (error) System.exit(1);
            System.out.println("Java syntax parsed: " + files.length + " source files");
        }
    }
}
