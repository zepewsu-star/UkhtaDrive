import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import ru.sntparma.invest.Model;
import ru.sntparma.invest.SignalEngine;

public class SignalEngineTest {
    private static void check(boolean v, String message) {
        if (!v) throw new AssertionError(message);
    }

    private static Model.Quote quote(List<Double> prices, int daysOld) {
        List<Model.Candle> candles = new ArrayList<>();
        for (int i = 0; i < prices.size(); i++) {
            candles.add(new Model.Candle(LocalDate.now().minusDays(daysOld + prices.size() - 1 - i).toString(), prices.get(i)));
        }
        return new Model.Quote("TEST", "Тестовый актив", prices.get(prices.size() - 1),
                LocalDate.now().minusDays(daysOld).toString(), candles);
    }

    public static void main(String[] args) {
        List<Double> less = new ArrayList<>();
        for (int i = 0; i < 20; i++) less.add(100.0 + i);
        check("NO_DATA".equals(SignalEngine.evaluate(quote(less, 0), 0.06).status),
                "Отказ при недостатке данных");
        List<Double> declining = new ArrayList<>();
        for (int i = 0; i < 90; i++) declining.add(200.0 - i * 1.0);
        check("WAIT".equals(SignalEngine.evaluate(quote(declining, 0), 0.06).status),
                "Нельзя рекомендовать покупку на падающем тренде");
        check("NO_DATA".equals(SignalEngine.evaluate(quote(declining, 9), 0.06).status),
                "Нельзя рекомендовать по устаревшим данным");
        List<Double> flat = new ArrayList<>();
        for (int i = 0; i < 90; i++) flat.add(100.0);
        check(!"BUY".equals(SignalEngine.evaluate(quote(flat, 0), 0.06).status),
                "На боковом рынке нет обоснованного сигнала");
        // Убедиться, что критерии иногда могут выдать BUY, а не всегда WAIT.
        boolean foundBuy = false;
        for (int seed = 0; seed < 800 && !foundBuy; seed++) {
            Random random = new Random(seed);
            List<Double> rising = new ArrayList<>();
            double point = 100;
            for (int i = 0; i < 85; i++) {
                point *= 1 + 0.0020 + random.nextGaussian() * 0.007;
                rising.add(point);
            }
            if ("BUY".equals(SignalEngine.evaluate(quote(rising, 0), 0.06).status)) foundBuy = true;
        }
        check(foundBuy, "Положительный сигнал должен быть достижим");
        System.out.println("SignalEngine: 5 checks passed");
    }
}
